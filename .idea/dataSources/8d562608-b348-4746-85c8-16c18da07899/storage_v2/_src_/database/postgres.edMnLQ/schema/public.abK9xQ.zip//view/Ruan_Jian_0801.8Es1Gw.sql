create view 软件0801(sno, sname, cname, grade) as
SELECT students.sno,
       students.sname,
       course.cname,
       sc.grade
FROM students,
     course,
     sc
WHERE students.classon::text = 'Rj0801'::text
  AND students.sno::text = sc.sno::text
  AND sc.cno::text = course.cno::text;

alter table 软件0801
    owner to postgres;

