create view scg1(sno, sname, classon, cname, grade) as
SELECT students.sno,
       students.sname,
       students.classon,
       course.cname,
       sc.grade
FROM students,
     course,
     sc
WHERE students.sno::text = sc.sno::text
  AND sc.cno::text = course.cno::text;

alter table scg1
    owner to postgres;

